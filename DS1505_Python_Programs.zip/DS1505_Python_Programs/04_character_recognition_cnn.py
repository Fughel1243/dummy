"""Experiment 4: CNN character recognition. Dataset CSV must have image,label columns."""
from pathlib import Path
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from PIL import Image
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Conv2D,MaxPooling2D,Flatten,Dense,Dropout
from tensorflow.keras.utils import to_categorical
DATA_DIR=Path('CharacterR')  # Put extracted dataset folder here; it should contain english.csv and image files.
CSV_PATH=DATA_DIR/'english.csv'; IMG_SIZE=28
if not CSV_PATH.exists(): raise FileNotFoundError(f'Missing {CSV_PATH}. Download/extract the CharacterR dataset; see README.md.')
df=pd.read_csv(CSV_PATH)
if not {'image','label'}.issubset(df.columns): raise ValueError("CSV must contain 'image' and 'label' columns")
images=[]; labels=[]
for _,row in df.iterrows():
    p=DATA_DIR/str(row['image'])
    if not p.exists(): continue
    im=Image.open(p).convert('L').resize((IMG_SIZE,IMG_SIZE)); images.append(np.asarray(im,dtype='float32')/255.0); labels.append(str(row['label']))
if not images: raise ValueError('No images found. Check image paths in the CSV.')
X=np.array(images)[...,None]; enc=LabelEncoder(); y=enc.fit_transform(labels); y_cat=to_categorical(y,num_classes=len(enc.classes_))
X_train,X_test,y_train,y_test=train_test_split(X,y_cat,test_size=.2,random_state=42,stratify=y)
model=Sequential([Conv2D(32,3,activation='relu',input_shape=(IMG_SIZE,IMG_SIZE,1)),MaxPooling2D(),Conv2D(64,3,activation='relu'),MaxPooling2D(),Flatten(),Dense(128,activation='relu'),Dropout(.5),Dense(len(enc.classes_),activation='softmax')])
model.compile(optimizer='adam',loss='categorical_crossentropy',metrics=['accuracy']); model.summary()
h=model.fit(X_train,y_train,epochs=10,batch_size=64,validation_split=.2)
loss,acc=model.evaluate(X_test,y_test,verbose=0); print(f'Test accuracy: {acc:.2%}')
pred=model.predict(X_test[:10],verbose=0).argmax(axis=1); true=y_test[:10].argmax(axis=1)
plt.figure(figsize=(10,4))
for i in range(min(10,len(pred))):
    plt.subplot(2,5,i+1); plt.imshow(X_test[i,:,:,0],cmap='gray'); plt.title(f"Pred:{enc.classes_[pred[i]]} / True:{enc.classes_[true[i]]}"); plt.axis('off')
plt.tight_layout(); plt.show()
