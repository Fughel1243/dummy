"""Experiment 7: LSTM sentiment classifier. Tiny demo dataset; use more data for meaningful results."""
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Embedding,LSTM,Dense,Dropout
from tensorflow.keras.utils import to_categorical
DATA={'text':['I love this product!','This is the worst experience I have had.','Amazing service and great quality!','I am disappointed with the outcome.','The movie was fantastic and inspiring!','I do not like this at all.','Such a wonderful experience!','This is a terrible waste of money.','Had a great time!','Completely ruined my day.'],'sentiment':['positive','negative','positive','negative','positive','negative','positive','negative','positive','negative']}
df=pd.DataFrame(DATA); df.to_csv('sentiment_dataset.csv',index=False)
enc=LabelEncoder(); y=enc.fit_transform(df.sentiment); tok=Tokenizer(num_words=5000,oov_token='<UNK>'); tok.fit_on_texts(df.text); X=pad_sequences(tok.texts_to_sequences(df.text),maxlen=100)
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42,stratify=y); ytr_cat=to_categorical(ytr,2); yte_cat=to_categorical(yte,2)
model=Sequential([Embedding(5000,128,input_length=100),LSTM(128),Dropout(.5),Dense(2,activation='softmax')]); model.compile(optimizer='adam',loss='categorical_crossentropy',metrics=['accuracy'])
h=model.fit(Xtr,ytr_cat,epochs=25,batch_size=4,validation_data=(Xte,yte_cat),verbose=2)
loss,acc=model.evaluate(Xte,yte_cat,verbose=0); print(f'Test accuracy: {acc:.2%}')
texts=['I love this product!','This is the worst experience.']; probs=model.predict(pad_sequences(tok.texts_to_sequences(texts),maxlen=100),verbose=0)
for t,p in zip(texts,probs): print(f'{t} -> {enc.inverse_transform([int(p.argmax())])[0]} ({p.max():.3f})')
plt.figure(figsize=(10,4)); plt.subplot(1,2,1); plt.plot(h.history['accuracy'],label='train'); plt.plot(h.history['val_accuracy'],label='validation'); plt.legend(); plt.title('Accuracy')
plt.subplot(1,2,2); plt.plot(h.history['loss'],label='train'); plt.plot(h.history['val_loss'],label='validation'); plt.legend(); plt.title('Loss'); plt.tight_layout(); plt.show()
