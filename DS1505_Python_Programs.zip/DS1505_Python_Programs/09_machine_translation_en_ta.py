"""Experiment 9: LSTM encoder-decoder English-to-Tamil demo; tiny corpus is for demonstration only."""
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, Model
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
english=['hello','how are you','i am fine','thank you','good morning','what is your name','good night','welcome']
tamil=['வணக்கம்','நீங்கள் எப்படி இருக்கிறீர்கள்','நான் நலம்','நன்றி','காலை வணக்கம்','உங்கள் பெயர் என்ன','இனிய இரவு','நல்வரவு']
target=['<start> '+s+' <end>' for s in tamil]
et=Tokenizer(filters=''); et.fit_on_texts(english); es=et.texts_to_sequences(english); maxe=max(map(len,es)); enc_data=pad_sequences(es,maxlen=maxe,padding='post'); ev=len(et.word_index)+1
tt=Tokenizer(filters=''); tt.fit_on_texts(target); ts=tt.texts_to_sequences(target); maxt=max(map(len,ts)); tv=len(tt.word_index)+1; dec_in=pad_sequences([s[:-1] for s in ts],maxlen=maxt-1,padding='post'); dec_out=pad_sequences([s[1:] for s in ts],maxlen=maxt-1,padding='post')
latent=128; ei=layers.Input(shape=(maxe,)); ee=layers.Embedding(ev,latent,mask_zero=True)(ei); _,sh,sc=layers.LSTM(latent,return_state=True)(ee)
di=layers.Input(shape=(maxt-1,)); de=layers.Embedding(tv,latent,mask_zero=True)(di); dl=layers.LSTM(latent,return_sequences=True); dout=dl(de,initial_state=[sh,sc]); do=layers.Dense(tv,activation='softmax')(dout)
model=Model([ei,di],do); model.compile(optimizer='adam',loss='sparse_categorical_crossentropy',metrics=['accuracy']); model.summary(); model.fit([enc_data,dec_in],dec_out,epochs=300,batch_size=4,verbose=0)
# Greedy decode with explicit <start>/<end> tokens.
rev={i:w for w,i in tt.word_index.items()}; start=tt.word_index['<start>']; end=tt.word_index['<end>']
enc_model=Model(ei,[sh,sc]); state_h=layers.Input(shape=(latent,)); state_c=layers.Input(shape=(latent,)); state_inputs=[state_h,state_c]
one=layers.Input(shape=(1,))
# Reuse the trained decoder embedding, LSTM, and dense layers by name/reference.
dec_emb_layer=model.layers[4]; dec_lstm=model.layers[5]; dec_dense=model.layers[6]
step_emb=dec_emb_layer(one); step_out,nh,nc=dec_lstm(step_emb,initial_state=state_inputs); step_probs=dec_dense(step_out); dec_model=Model([one,state_h,state_c],[step_probs,nh,nc])
def translate(sentence):
    seq=pad_sequences(et.texts_to_sequences([sentence.lower()]),maxlen=maxe,padding='post'); h,c=enc_model.predict(seq,verbose=0); token=start; words=[]
    for _ in range(maxt):
        probs,h,c=dec_model.predict([np.array([[token]]),h,c],verbose=0); token=int(probs[0,-1].argmax())
        if token==end or token==0: break
        words.append(rev.get(token,''))
    return ' '.join(words)
for s in ['hello','good morning','thank you']: print(s,'->',translate(s))
print('Note: a tiny parallel corpus cannot provide reliable general translation.')
