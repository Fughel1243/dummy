"""Experiment 6: Next-word language model with SimpleRNN. Uses dataset1.txt in this folder."""
from pathlib import Path
import numpy as np, matplotlib.pyplot as plt
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense,SimpleRNN,Embedding
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.utils import to_categorical
path=Path('dataset1.txt')
if not path.exists(): raise FileNotFoundError('Create dataset1.txt with training text; see README.md.')
text=path.read_text(encoding='utf-8').lower().strip()
tokenizer=Tokenizer(filters='!"#$%&()*+,-/:;<=>?@[\]^_`{|}~\t\n'); tokenizer.fit_on_texts([text]); vocab=len(tokenizer.word_index)+1
sequences=[]
for line in text.splitlines():
    ids=tokenizer.texts_to_sequences([line])[0]
    for i in range(1,len(ids)): sequences.append(ids[:i+1])
if not sequences: raise ValueError('dataset1.txt needs several lines with multiple words.')
maxlen=max(map(len,sequences)); arr=pad_sequences(sequences,maxlen=maxlen,padding='pre'); X=arr[:,:-1]; y=to_categorical(arr[:,-1],num_classes=vocab)
model=Sequential([Embedding(vocab,100,input_length=maxlen-1),SimpleRNN(128),Dense(vocab,activation='softmax')]); model.compile(optimizer='adam',loss='categorical_crossentropy',metrics=['accuracy']); model.summary()
h=model.fit(X,y,epochs=100,batch_size=64,verbose=1)
def generate(seed,steps=20):
    for _ in range(steps):
        seq=tokenizer.texts_to_sequences([seed])[0]; seq=pad_sequences([seq],maxlen=maxlen-1,padding='pre'); idx=int(model.predict(seq,verbose=0).argmax())
        word=tokenizer.index_word.get(idx,'')
        if not word: break
        seed+=' '+word
        if '.' in word: break
    return seed
print('Generated:',generate('deep learning has'))
plt.plot(h.history['accuracy']); plt.title('Training accuracy'); plt.show(); plt.plot(h.history['loss']); plt.title('Training loss'); plt.show()
