"""Experiment 5: Face classification CNN. Expected folders: dataset/{train,val,test}/PERSON_NAME/*.jpg"""
from pathlib import Path
import cv2, numpy as np, matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Conv2D,MaxPooling2D,Flatten,Dense
DATASET=Path('face_dataset'); SIZE=64
cascade=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
def load_split(split):
    xs=[]; ys=[]; base=DATASET/split
    if not base.exists(): raise FileNotFoundError(f'Missing {base}; see README.md for folder structure.')
    for folder in sorted(p for p in base.iterdir() if p.is_dir()):
        for path in folder.iterdir():
            if path.suffix.lower() not in {'.jpg','.jpeg','.png','.bmp'}: continue
            img=cv2.imread(str(path))
            if img is None: continue
            gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY); faces=cascade.detectMultiScale(gray,1.1,5)
            if len(faces):
                x,y,w,h=faces[0]; face=img[y:y+h,x:x+w]
            else: face=img
            face=cv2.resize(face,(SIZE,SIZE)); xs.append(face.astype('float32')/255.0); ys.append(folder.name)
    if not xs: raise ValueError(f'No readable images found in {base}')
    return np.array(xs),np.array(ys)
Xtr,ytr=load_split('train'); Xv,yv=load_split('val'); Xte,yte=load_split('test')
le=LabelEncoder(); ytr=le.fit_transform(ytr)
unknown=(set(yv)|set(yte))-set(le.classes_)
if unknown: raise ValueError(f'Validation/test labels absent from train: {unknown}')
yv=le.transform(yv); yte=le.transform(yte)
model=Sequential([Conv2D(32,3,activation='relu',input_shape=(SIZE,SIZE,3)),MaxPooling2D(),Conv2D(64,3,activation='relu'),MaxPooling2D(),Flatten(),Dense(100,activation='relu'),Dense(len(le.classes_),activation='softmax')])
model.compile(optimizer='adam',loss='sparse_categorical_crossentropy',metrics=['accuracy']); h=model.fit(Xtr,ytr,validation_data=(Xv,yv),epochs=10,batch_size=32)
loss,acc=model.evaluate(Xte,yte,verbose=0); print(f'Test accuracy: {acc:.2%}')
pred=model.predict(Xte,verbose=0).argmax(axis=1); print(classification_report(yte,pred,target_names=le.classes_,zero_division=0))
ConfusionMatrixDisplay(confusion_matrix(yte,pred),display_labels=le.classes_).plot(xticks_rotation=45); plt.tight_layout(); plt.show()
plt.figure(figsize=(10,4)); plt.subplot(1,2,1); plt.plot(h.history['accuracy'],label='train'); plt.plot(h.history['val_accuracy'],label='validation'); plt.legend(); plt.title('Accuracy')
plt.subplot(1,2,2); plt.plot(h.history['loss'],label='train'); plt.plot(h.history['val_loss'],label='validation'); plt.legend(); plt.title('Loss'); plt.tight_layout(); plt.show()
