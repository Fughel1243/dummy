# DS1505-P Fundamentals of Deep Learning — Python programs

This pack contains one standalone `.py` file for each of the **10 experiments** listed in the uploaded DS1505-P lab manual. Programs are based on the experiment topics and architectures in that manual; paths and a few compatibility issues have been made portable.

## Programs
1. `01_perceptron_and_gate.py` — perceptron AND gate + decision boundary
2. `02_xor_dnn.py` — XOR using a Keras DNN
3. `03_mnist_dense_network.py` — MNIST classification using a feed-forward network
4. `04_character_recognition_cnn.py` — character recognition CNN
5. `05_face_recognition_cnn.py` — face classification CNN
6. `06_language_modeling_rnn.py` — next-word RNN language model
7. `07_sentiment_analysis_lstm.py` — LSTM sentiment classification
8. `08_pos_tagging_seq2seq.py` — sequence-to-sequence POS tagging
9. `09_machine_translation_en_ta.py` — English-to-Tamil encoder-decoder demo
10. `10_image_augmentation_gan.py` — GAN image generation on MNIST

## Setup
Use Python 3.10 or 3.11 in a virtual environment. From this directory:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

Run any program independently, e.g. `python 01_perceptron_and_gate.py`. TensorFlow programs may take time and may use the network to download MNIST on first run.

## Extra datasets needed
- **Experiment 4:** Download/extract the CharacterR dataset referenced by the lab manual into a folder named `CharacterR/`. It should contain `english.csv` with `image` and `label` columns, plus the image paths referenced by that CSV.
- **Experiment 5:** Place face images in `face_dataset/train/PERSON_NAME/`, `face_dataset/val/PERSON_NAME/`, and `face_dataset/test/PERSON_NAME/`. Use the same person subfolder names in all splits. Images can be color or grayscale; OpenCV is used for face detection. Use images you have permission to process.
- **Experiment 6:** `dataset1.txt` is included as a small example corpus. Replace it with a larger text corpus for useful generation.
- **Experiment 7:** The sentiment script creates a tiny 10-row sample CSV itself. This is only a pipeline demonstration and is far too small for reliable sentiment predictions.
- **Experiments 8 and 9:** The manual's small sample datasets are included in the scripts. Their scores/output are illustrative, not production-quality. For machine translation, use a substantially larger and verified English–Tamil parallel corpus for meaningful results.

## Notes
- Each file can be run on its own; you do not need to run the other experiments first.
- Plot windows may open during execution.
- The GAN script defaults to 5,000 epochs to match the manual and can take a long time. For a quick smoke test, temporarily set `EPOCHS = 20` and `SAVE_EVERY = 10`.
- CNN/LSTM/RNN accuracy depends on random initialization, package versions, dataset size, and training conditions; the manual's printed outputs are not guaranteed to repeat exactly.
