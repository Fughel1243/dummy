"""Experiment 2: Solve XOR with a small Keras DNN."""
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
X=np.array([[0,0],[0,1],[1,0],[1,1]], dtype='float32')
y=np.array([[0],[1],[1],[0]], dtype='float32')
tf.keras.utils.set_random_seed(42)
model=Sequential([Dense(8, input_shape=(2,), activation='sigmoid'), Dense(1, activation='sigmoid')])
model.compile(optimizer=Adam(learning_rate=0.03), loss='binary_crossentropy', metrics=['accuracy'])
history=model.fit(X,y,epochs=3000,verbose=0,callbacks=[tf.keras.callbacks.EarlyStopping(monitor='loss',patience=150,restore_best_weights=True)])
probs=model.predict(X,verbose=0).ravel()
for xi,p,t in zip(X,probs,y.ravel()): print(f'{xi.astype(int)} -> probability={p:.4f}, class={int(p>=0.5)}, target={int(t)}')
plt.figure(figsize=(10,4)); plt.subplot(1,2,1); plt.plot(history.history['loss']); plt.title('Training loss'); plt.xlabel('Epoch')
plt.subplot(1,2,2); plt.plot(history.history['accuracy']); plt.title('Training accuracy'); plt.xlabel('Epoch'); plt.tight_layout(); plt.show()
