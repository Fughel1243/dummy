"""Experiment 10: Fully-connected GAN trained on MNIST to generate 28x28 digit images."""
from pathlib import Path
import numpy as np, matplotlib.pyplot as plt, tensorflow as tf
from tensorflow.keras import layers, Model, Sequential
OUT=Path('gan_images'); OUT.mkdir(exist_ok=True)
LATENT=100; BATCH=128; EPOCHS=5000; SAVE_EVERY=500
IMAGE_SHAPE=(28,28,1)
def build_generator():
    return Sequential([layers.Input((LATENT,)),layers.Dense(256),layers.LeakyReLU(negative_slope=.2),layers.BatchNormalization(momentum=.8),layers.Dense(512),layers.LeakyReLU(negative_slope=.2),layers.BatchNormalization(momentum=.8),layers.Dense(1024),layers.LeakyReLU(negative_slope=.2),layers.BatchNormalization(momentum=.8),layers.Dense(784,activation='tanh'),layers.Reshape(IMAGE_SHAPE)],name='generator')
def build_discriminator():
    return Sequential([layers.Input(IMAGE_SHAPE),layers.Flatten(),layers.Dense(512),layers.LeakyReLU(negative_slope=.2),layers.Dense(256),layers.LeakyReLU(negative_slope=.2),layers.Dense(1,activation='sigmoid')],name='discriminator')
def save_grid(generator,epoch):
    imgs=generator.predict(np.random.normal(size=(25,LATENT)).astype('float32'),verbose=0); imgs=(imgs+1)/2
    fig,axs=plt.subplots(5,5,figsize=(5,5))
    for ax,img in zip(axs.ravel(),imgs): ax.imshow(img[:,:,0],cmap='gray'); ax.axis('off')
    fig.suptitle(f'Epoch {epoch}'); fig.tight_layout(); fig.savefig(OUT/f'mnist_{epoch}.png'); plt.close(fig)
(x,_),_=tf.keras.datasets.mnist.load_data(); x=(x.astype('float32')/127.5)-1; x=x[...,None]
g=build_generator(); d=build_discriminator(); d.compile(optimizer=tf.keras.optimizers.Adam(0.0002,beta_1=.5),loss='binary_crossentropy',metrics=['accuracy'])
z=layers.Input((LATENT,)); d.trainable=False; gan=Model(z,d(g(z))); gan.compile(optimizer=tf.keras.optimizers.Adam(0.0002,beta_1=.5),loss='binary_crossentropy')
d_losses=[]; g_losses=[]
for epoch in range(1,EPOCHS+1):
    idx=np.random.randint(0,len(x),BATCH); real=x[idx]; noise=np.random.normal(size=(BATCH,LATENT)).astype('float32'); fake=g.predict(noise,verbose=0)
    d.trainable=True; dr=d.train_on_batch(real,np.ones((BATCH,1))); df=d.train_on_batch(fake,np.zeros((BATCH,1)))
    noise=np.random.normal(size=(BATCH,LATENT)).astype('float32'); d.trainable=False; gl=gan.train_on_batch(noise,np.ones((BATCH,1)))
    d_losses.append(float((dr[0]+df[0])/2)); g_losses.append(float(gl[0] if isinstance(gl,(list,tuple,np.ndarray)) else gl))
    if epoch%100==0: print(f'{epoch}/{EPOCHS} D loss={d_losses[-1]:.4f}, G loss={g_losses[-1]:.4f}')
    if epoch%SAVE_EVERY==0: save_grid(g,epoch)
g.save('mnist_generator.keras'); np.savez('gan_losses.npz',discriminator=d_losses,generator=g_losses); save_grid(g,EPOCHS)
plt.plot(d_losses,label='Discriminator'); plt.plot(g_losses,label='Generator'); plt.legend(); plt.title('GAN losses'); plt.show()
print('Saved generator to mnist_generator.keras and sample grids to gan_images/.')
