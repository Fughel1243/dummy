"""Experiment 1: Perceptron learning algorithm for an AND gate."""
import numpy as np
import matplotlib.pyplot as plt
X = np.array([[0,0],[0,1],[1,0],[1,1]])
y = np.array([0,0,0,1])
weights = np.array([0.3, -0.1], dtype=float)
bias, learning_rate, epochs = 0.2, 0.1, 50
for epoch in range(epochs):
    errors = 0
    for xi, target in zip(X, y):
        pred = int(np.dot(weights, xi) + bias >= 0)
        if pred != target:
            delta = learning_rate * (target - pred)
            weights += delta * xi
            bias += delta
            errors += 1
    print(f"Epoch {epoch+1}: errors={errors}, weights={weights}, bias={bias:.3f}")
    if errors == 0:
        print("Training converged."); break
print("Final predictions:")
for xi, target in zip(X, y):
    pred = int(np.dot(weights, xi) + bias >= 0)
    print(f"{xi} -> {pred} (target {target})")
plt.scatter(X[:,0], X[:,1], c=y, cmap='bwr', edgecolors='black', s=100)
if abs(weights[1]) > 1e-10:
    xs=np.linspace(-0.2,1.2,100); plt.plot(xs, -(weights[0]*xs+bias)/weights[1], label='Decision boundary')
plt.xlabel('x1'); plt.ylabel('x2'); plt.title('Perceptron: AND gate'); plt.grid(True); plt.legend(); plt.show()
