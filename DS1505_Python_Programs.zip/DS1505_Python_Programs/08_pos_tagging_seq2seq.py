"""Experiment 8: Sequence-to-sequence POS tagging using a tiny illustrative dataset."""
import numpy as np, matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras import layers, Model
from tensorflow.keras.preprocessing.sequence import pad_sequences
sentences=[['I','love','machine','learning'],['He','is','working','on','a','project'],['Deep','learning','is','fascinating'],['She','likes','natural','language','processing']]
tags=[['PRON','VERB','NOUN','NOUN'],['PRON','VERB','VERB','ADP','DET','NOUN'],['ADJ','NOUN','VERB','ADJ'],['PRON','VERB','ADJ','NOUN','NOUN']]
words=sorted({w.lower() for s in sentences for w in s}); tagset=sorted({t for row in tags for t in row}); w2i={w:i+1 for i,w in enumerate(words)}; t2i={t:i+1 for i,t in enumerate(tagset)}; i2t={v:k for k,v in t2i.items()}
maxlen=max(map(len,sentences)); X=pad_sequences([[w2i[w.lower()] for w in s] for s in sentences],maxlen=maxlen,padding='post'); Y=pad_sequences([[t2i[t] for t in row] for row in tags],maxlen=maxlen,padding='post')
# Teacher-forced decoder inputs are the tag sequence shifted right; zero is the start/padding token.
D=np.zeros_like(Y); D[:,1:]=Y[:,:-1]
enc_in=layers.Input(shape=(maxlen,)); enc=layers.Embedding(len(w2i)+1,64,mask_zero=True)(enc_in); _,h,c=layers.LSTM(128,return_state=True)(enc)
dec_in=layers.Input(shape=(maxlen,)); de=layers.Embedding(len(t2i)+1,64,mask_zero=True)(dec_in); dout=layers.LSTM(128,return_sequences=True)(de,initial_state=[h,c]); out=layers.Dense(len(t2i)+1,activation='softmax')(dout)
model=Model([enc_in,dec_in],out); model.compile(optimizer='adam',loss='sparse_categorical_crossentropy',metrics=['accuracy']); model.summary()
hist=model.fit([X,D],Y,epochs=100,batch_size=2,verbose=0); print('Final training accuracy:',hist.history['accuracy'][-1])
def tag_sentence(sentence):
    toks=sentence.split(); seq=pad_sequences([[w2i.get(w.lower(),0) for w in toks]],maxlen=maxlen,padding='post'); dec=np.zeros((1,maxlen),dtype='int32'); pred=model.predict([seq,dec],verbose=0).argmax(axis=-1)[0]
    return list(zip(toks,[i2t.get(int(idx),'UNK') for idx in pred[:len(toks)]]))
print(tag_sentence('She likes deep learning'))
plt.plot(hist.history['accuracy']); plt.title('Training accuracy'); plt.show(); plt.plot(hist.history['loss']); plt.title('Training loss'); plt.show()
