"""Experiment 3: Handwritten digit classification using a feed-forward neural network."""
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Flatten, Dense
from tensorflow.keras.utils import to_categorical
(x_train,y_train),(x_test,y_test)=tf.keras.datasets.mnist.load_data()
x_train=x_train.astype('float32')/255.0; x_test=x_test.astype('float32')/255.0
y_train_cat=to_categorical(y_train,10); y_test_cat=to_categorical(y_test,10)
model=Sequential([Flatten(input_shape=(28,28)),Dense(128,activation='relu'),Dense(10,activation='softmax')])
model.compile(optimizer='adam',loss='categorical_crossentropy',metrics=['accuracy'])
h=model.fit(x_train,y_train_cat,epochs=10,batch_size=64,validation_split=0.2)
loss,acc=model.evaluate(x_test,y_test_cat,verbose=0); print(f'Test accuracy: {acc:.4f}; test loss: {loss:.4f}')
probs=model.predict(x_test[:10],verbose=0); plt.figure(figsize=(10,4))
for i in range(10):
    plt.subplot(2,5,i+1); plt.imshow(x_test[i],cmap='gray'); plt.title(f'Pred {np.argmax(probs[i])} / True {y_test[i]}'); plt.axis('off')
plt.tight_layout(); plt.show()
plt.figure(figsize=(10,4)); plt.subplot(1,2,1); plt.plot(h.history['accuracy'],label='train'); plt.plot(h.history['val_accuracy'],label='validation'); plt.title('Accuracy'); plt.legend()
plt.subplot(1,2,2); plt.plot(h.history['loss'],label='train'); plt.plot(h.history['val_loss'],label='validation'); plt.title('Loss'); plt.legend(); plt.tight_layout(); plt.show()
